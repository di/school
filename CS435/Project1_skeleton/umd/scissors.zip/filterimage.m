% CMSC 426- Spring 2004
% Problem Set 4
% Filter image function
%
% Usage:  im2 = filterimage(im)
%
% Arguments:   
%            im     - image to be processed.
%
% Returns:
%            im2    - filtered image
%
% Author: 
% Konstantinos Bitsakos
% Department of Computer Science 
% University of Maryland, College Park
% kbits@cs.umd.edu
%
% February 2004

function im2 = filterimage(im)

%%%%%%%%
% TODO %
%%%%%%%%