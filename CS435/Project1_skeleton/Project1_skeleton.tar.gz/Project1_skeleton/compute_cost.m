%%
%% compute_cost.m
%%
%% Computational Photography Assignment 1
%%
%% John Novatnack
%% jmn27@cs.drexel.edu
%%
%% Adapted from previous skeleton code by:
%%
%% 	Konstantinos Bitsakos
%% 	Department of Computer Science 
%% 	University of Maryland, College Park
%% 	kbits@cs.umd.edu
%%
%% Further reference on Intelligent Scissors:
%%	"Intelligent Scissors for Image Composition", E. Mortensen and W. Barret
%%	SIGGRAPH 1995.
%%
%%
%% Given a NxM image computes a NxMx8 matrix containing the cost of each of the
%% 8 links at each pixel.
%%
%% INPUT
%%	1) img		- N x M x 3 image
%% 
%% OUTPUT
%%	1) cost_matrix	- N x M x 8 cost matrix
%%
function [cost_matrix] = compute_cost(img)

  img = double(img);

  %%
  %% Create the kernels 
  %% 


  %%
  %% Compute the cost for the RGB bands
  %%
  %%
	

  %%
  %% cost_matrix is defined as the magnitude of the cost over the RGB bands
	%% and has negated and normalized with respect the maximum value
  %%

 
  


  
  




  

